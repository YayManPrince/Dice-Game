﻿using System.Collections;
using System.Threading.Tasks;
using System.Text;
using System;

namespace DiceGame
{
    class DiceG
    {
        static void Main(string[] args)
        {
            int playerRandom;
            int enemyRandom ;

            int playerScore = 0;
            int enemyScore = 0;     

            Random random = new Random();

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Please press any key to roll dice: ");
                Console.ReadKey();

                playerRandom = random.Next(1, 7);
                Console.WriteLine(" PLayer rolled a: " + playerRandom);

                Console.WriteLine("....");
                System.Threading.Thread.Sleep(1000);

                enemyRandom = random.Next(1, 7);
                Console.WriteLine("Enemy rolled a: " + enemyRandom);

                if (playerRandom > enemyRandom)
                {
                    playerScore++;
                    Console.WriteLine("Player wins round ");
                }
                else if (enemyRandom > playerRandom)
                {
                    enemyScore++;
                    Console.WriteLine("Enemy wins round ");
                }else
                {
                    Console.WriteLine("Its a tie");
                }

                Console.WriteLine("The score is: player - " + playerScore + " Enemy - " + enemyScore + "\n");

            }
            if (playerScore > enemyScore)
            {
                Console.WriteLine("PLayer wins the Game");
            }else if (enemyScore > playerScore)
            {
                Console.WriteLine("Enemy wins the game");
            }
            else
            {
                Console.WriteLine("What are the chances that the game is a TIE!");
            }

            Console.ReadKey();
            
            
        }
    }
}
